from django.contrib import admin
from .models import Professor,Project

admin.site.register(Professor)
admin.site.register(Project)