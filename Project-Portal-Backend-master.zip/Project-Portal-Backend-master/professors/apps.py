from django.apps import AppConfig


class ProfessorsConfig(AppConfig):
    name = 'professors'
