from django.contrib import admin
from .models import Promo

admin.site.register(Promo)

# Register your models here.
